# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rlagent', 'rlagent..ipynb_checkpoints']

package_data = \
{'': ['*']}

install_requires = \
['gym>=0.18.0,<0.19.0',
 'jupyterlab>=3.0.7,<4.0.0',
 'seaborn>=0.11.1,<0.12.0',
 'torch>=1.7.1,<2.0.0']

entry_points = \
{'console_scripts': ['run_agent = rlagent.simulation:run']}

setup_kwargs = {
    'name': 'rlagent',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Ryan Anderson',
    'author_email': 'ryan@anderson.vc',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
